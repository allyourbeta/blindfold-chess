import { create } from "zustand";
import { getThemePreference, setThemePreference, type ThemePreference } from "@/api/localStore";
import type { Color } from "chess.js";

export interface SkillLevel {
  label: string;
  depth: number;
  skill: number;
}

/** Unchanged from the original app — depth/skill values must not drift. */
export const SKILL_LEVELS: SkillLevel[] = [
  { label: "Beginner (~800)", depth: 1, skill: 0 },
  { label: "Casual (~1200)", depth: 3, skill: 5 },
  { label: "Club (~1500)", depth: 5, skill: 8 },
  { label: "Intermediate (~1800)", depth: 8, skill: 12 },
  { label: "Strong (~2000)", depth: 10, skill: 15 },
  { label: "Expert (~2200)", depth: 12, skill: 18 },
  { label: "Master (~2500)", depth: 15, skill: 20 },
  { label: "Full Strength", depth: 18, skill: 20 },
];

interface SettingsState {
  playerColor: Color;
  skillIndex: number;
  voiceOutputEnabled: boolean;
  theme: ThemePreference;
  setPlayerColor(color: Color): void;
  setSkillIndex(index: number): void;
  setVoiceOutputEnabled(enabled: boolean): void;
  setTheme(theme: ThemePreference): void;
  toggleTheme(): void;
}

function initialTheme(): ThemePreference {
  const stored = getThemePreference();
  if (stored) return stored;
  if (typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches) {
    return "dark";
  }
  return "light";
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  playerColor: "w",
  skillIndex: 2,
  voiceOutputEnabled: true,
  theme: initialTheme(),
  setPlayerColor: (color) => set({ playerColor: color }),
  setSkillIndex: (index) => set({ skillIndex: index }),
  setVoiceOutputEnabled: (enabled) => set({ voiceOutputEnabled: enabled }),
  setTheme: (theme) => {
    setThemePreference(theme);
    set({ theme });
  },
  toggleTheme: () => get().setTheme(get().theme === "dark" ? "light" : "dark"),
}));
