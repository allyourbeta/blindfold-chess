import { useEffect } from "react";
import { useGameStore } from "@/state/gameStore";
import { useSettingsStore } from "@/state/settingsStore";
import { useSpeechStore } from "@/state/speechStore";
import { movePhraseClips, gameEndPhraseClips } from "@/services/speech/phrase";
import { playMoveTone, playCaptureTone, playErrorTone } from "@/services/audio/sfx";

let audioCtx: AudioContext | null = null;
function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new Ctor();
  }
  return audioCtx;
}

/** Unlocks audio playback on iOS — call this from a real user gesture (the New Game tap). */
export function unlockAudioOutput(): void {
  const ctx = getAudioContext();
  if (ctx.state === "suspended") void ctx.resume();
  const unlockEl = new Audio();
  unlockEl.muted = true;
  unlockEl.play().catch(() => {}).finally(() => unlockEl.pause());
}

const clipCache = new Map<string, HTMLAudioElement>();
function getClipElement(id: string): HTMLAudioElement {
  let el = clipCache.get(id);
  if (!el) {
    el = new Audio(`/audio/${id}.wav`);
    el.preload = "auto";
    clipCache.set(id, el);
  }
  return el;
}

function playOneClip(id: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const el = getClipElement(id);
    el.currentTime = 0;
    const cleanup = () => {
      el.removeEventListener("ended", onEnded);
      el.removeEventListener("error", onError);
    };
    const onEnded = () => {
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error(`clip "${id}" failed to play`));
    };
    el.addEventListener("ended", onEnded);
    el.addEventListener("error", onError);
    el.play().catch(onError);
  });
}

const CLIP_GAP_MS = 90;

/** Plays clips back to back — never starts the next one before the previous finished. */
async function playClipSequence(ids: string[]): Promise<void> {
  for (const id of ids) {
    await playOneClip(id);
    await new Promise((r) => setTimeout(r, CLIP_GAP_MS));
  }
}

function speakFallback(text: string): void {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
}

async function speakWithFallback(clips: string[], fallbackText: string): Promise<void> {
  if (!clips.length) return;
  useSpeechStore.getState().setSpeaking(true);
  try {
    await playClipSequence(clips);
  } catch {
    speakFallback(fallbackText);
  } finally {
    useSpeechStore.getState().setSpeaking(false);
  }
}

/** Reacts to gameStore's audioEvent: confirmation tones always, spoken moves when voice output is enabled. */
export function useSpeechOutput() {
  const audioEvent = useGameStore((s) => s.audioEvent);
  const voiceOutputEnabled = useSettingsStore((s) => s.voiceOutputEnabled);

  useEffect(() => {
    if (!audioEvent) return;
    const ctx = getAudioContext();

    if (audioEvent.kind === "move") {
      if (audioEvent.move.isCapture()) playCaptureTone(ctx);
      else playMoveTone(ctx);
      if (voiceOutputEnabled) {
        const clips = movePhraseClips(audioEvent.move);
        void speakWithFallback(clips, clips.join(" "));
      }
    } else if (audioEvent.kind === "illegal-move") {
      playErrorTone(ctx);
      if (voiceOutputEnabled) speakFallback(audioEvent.spoken);
    } else if (audioEvent.kind === "game-end") {
      if (voiceOutputEnabled) {
        const clips = gameEndPhraseClips(audioEvent.reason);
        void speakWithFallback(clips, clips.join(" "));
      }
    }
  }, [audioEvent, voiceOutputEnabled]);
}
