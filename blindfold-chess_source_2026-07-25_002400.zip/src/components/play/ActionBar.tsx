import { Undo2, Lightbulb, Flag, RotateCcw, ClipboardCopy } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { useGameStore } from "@/state/gameStore";

export function ActionBar() {
  const gameOverFlag = useGameStore((s) => s.gameOverFlag);
  const moveCount = useGameStore((s) => s.moveHistory.length);
  const doTakeback = useGameStore((s) => s.doTakeback);
  const requestHint = useGameStore((s) => s.requestHint);
  const doResign = useGameStore((s) => s.doResign);
  const startNewGame = useGameStore((s) => s.startNewGame);
  const copyPgn = useGameStore((s) => s.copyPgn);

  return (
    <div className="flex flex-wrap justify-center gap-2 pt-1">
      <Button
        variant="secondary"
        size="sm"
        disabled={gameOverFlag || moveCount === 0}
        onClick={doTakeback}
        title="Undo last move pair"
      >
        <Undo2 className="h-4 w-4" /> Takeback
      </Button>
      <Button variant="secondary" size="sm" disabled={gameOverFlag} onClick={requestHint} title="Show legal moves">
        <Lightbulb className="h-4 w-4" /> Hint
      </Button>
      <Button variant="secondary" size="sm" disabled={gameOverFlag} onClick={doResign}>
        <Flag className="h-4 w-4" /> Resign
      </Button>
      <Button variant="secondary" size="sm" onClick={() => void startNewGame()}>
        <RotateCcw className="h-4 w-4" /> New Game
      </Button>
      <Button variant="secondary" size="sm" onClick={() => void copyPgn()} title="Copy game notation">
        <ClipboardCopy className="h-4 w-4" /> PGN
      </Button>
    </div>
  );
}
