import { Sun, Moon, LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Toggle } from "@/components/ui/Toggle";
import { SegmentedControl } from "@/components/ui/SegmentedControl";
import { useGameStore } from "@/state/gameStore";
import { useSettingsStore, SKILL_LEVELS } from "@/state/settingsStore";
import { useTheme } from "@/hooks/useTheme";
import { unlockAudioOutput } from "@/hooks/useSpeechOutput";
import { PIECES_UNICODE } from "@/components/board/PieceGlyph";

interface MenuScreenProps {
  onPlay(): void;
  onSetup(): void;
}

export function MenuScreen({ onPlay, onSetup }: MenuScreenProps) {
  const { theme, toggleTheme } = useTheme();
  const playerColor = useSettingsStore((s) => s.playerColor);
  const setPlayerColor = useSettingsStore((s) => s.setPlayerColor);
  const skillIndex = useSettingsStore((s) => s.skillIndex);
  const setSkillIndex = useSettingsStore((s) => s.setSkillIndex);
  const voiceOutputEnabled = useSettingsStore((s) => s.voiceOutputEnabled);
  const setVoiceOutputEnabled = useSettingsStore((s) => s.setVoiceOutputEnabled);

  const engineStatus = useGameStore((s) => s.engineStatus);
  const startNewGame = useGameStore((s) => s.startNewGame);
  const retryEngine = useGameStore((s) => s.retryEngine);

  const engineReady = engineStatus === "ready";
  const engineFailed = engineStatus === "failed";

  async function handleStart() {
    unlockAudioOutput();
    if (engineFailed) {
      await retryEngine();
      return;
    }
    if (!engineReady) return;
    await startNewGame();
    onPlay();
  }

  return (
    <div className="mx-auto flex w-full max-w-lg flex-col gap-6 p-6 pb-10">
      <header className="border-b border-border-default pb-4 pt-2 text-center">
        <h1 className="text-3xl font-semibold tracking-wide text-text-accent">
          {PIECES_UNICODE.k} Blindfold
        </h1>
        <p className="mt-1 text-xs uppercase tracking-widest text-text-secondary">Chess Visualization Trainer</p>
        <button
          type="button"
          onClick={toggleTheme}
          aria-label="Toggle dark mode"
          className="mt-3 inline-flex h-11 w-11 items-center justify-center rounded-full text-text-secondary hover:bg-bg-surface-alt"
        >
          {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </button>
      </header>

      <div>
        <span className="mb-2 block text-xs uppercase tracking-wide text-text-secondary">Play as</span>
        <SegmentedControl<"w" | "b">
          aria-label="Play as"
          value={playerColor}
          onChange={setPlayerColor}
          options={[
            { value: "w", label: `${PIECES_UNICODE.K} White` },
            { value: "b", label: `${PIECES_UNICODE.k} Black` },
          ]}
        />
      </div>

      <div>
        <span className="mb-2 block text-xs uppercase tracking-wide text-text-secondary">Engine strength</span>
        <div className="grid grid-cols-2 gap-2">
          {SKILL_LEVELS.map((level, i) => (
            <button
              key={level.label}
              type="button"
              onClick={() => setSkillIndex(i)}
              aria-pressed={i === skillIndex}
              className={
                "min-h-11 rounded-xl border px-2 text-xs font-medium transition-colors " +
                (i === skillIndex
                  ? "border-transparent bg-bg-primary text-text-on-primary"
                  : "border-border-default bg-bg-surface text-text-primary hover:bg-bg-surface-alt")
              }
            >
              {level.label}
            </button>
          ))}
        </div>
      </div>

      <Toggle
        id="voice-output"
        checked={voiceOutputEnabled}
        onChange={setVoiceOutputEnabled}
        label="Speak engine moves aloud"
      />

      <div className="flex flex-col gap-3">
        <Button variant="primary" disabled={engineStatus === "loading"} onClick={() => void handleStart()}>
          {engineStatus === "loading" && <LoaderCircle className="h-4 w-4 animate-spin" />}
          {engineStatus === "loading" && "Loading Stockfish..."}
          {engineFailed && "Engine failed — Retry"}
          {engineReady && "New Game (Standard Position)"}
          {engineStatus === "idle" && "Loading Stockfish..."}
        </Button>
        <Button variant="secondary" disabled={!engineReady} onClick={onSetup}>
          Setup Position &amp; Play
        </Button>
      </div>

      <Card className="p-5">
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-text-accent">How to play</h3>
        <div className="space-y-1 text-sm leading-relaxed text-text-secondary">
          <p>Type moves in standard algebraic notation:</p>
          <p>
            <span className="font-mono text-text-primary">e4</span> — pawn to e4
          </p>
          <p>
            <span className="font-mono text-text-primary">Nf3</span> — knight to f3
          </p>
          <p>
            <span className="font-mono text-text-primary">Bxe5</span> — bishop captures on e5
          </p>
          <p>
            <span className="font-mono text-text-primary">O-O</span> — castle kingside
          </p>
          <p>
            <span className="font-mono text-text-primary">e8=Q</span> — pawn promotes to queen
          </p>
          <p className="mt-2">
            <span className="font-mono text-text-primary">peek</span> or <b>Spacebar</b> — see the board for 3
            seconds
            <br />
            <span className="font-mono text-text-primary">hint</span> — show legal moves
            <br />
            <span className="font-mono text-text-primary">history</span> — view past games &amp; stats
          </p>
          <p className="mt-2">Voice: say moves naturally, or use NATO letters (Alpha, Bravo, Charlie...).</p>
        </div>
      </Card>
    </div>
  );
}
