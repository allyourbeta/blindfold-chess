// The Unicode chess glyphs used to draw pieces — deliberately kept instead
// of remote piece images. This is the one exception to "no emoji in the UI".
export const PIECES_UNICODE: Record<string, string> = {
  K: "♔",
  Q: "♕",
  R: "♖",
  B: "♗",
  N: "♘",
  P: "♙",
  k: "♚",
  q: "♛",
  r: "♜",
  b: "♝",
  n: "♞",
  p: "♟",
};

export function PieceGlyph({ piece }: { piece: string }) {
  return (
    <span aria-label={piece} className="select-none text-[1.9rem] leading-none [text-shadow:0_1px_1px_rgba(0,0,0,0.2)]">
      {PIECES_UNICODE[piece] ?? ""}
    </span>
  );
}
