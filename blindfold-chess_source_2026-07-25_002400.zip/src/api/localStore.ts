import type { StoredGame } from "@/services/chess/gameSummary";

/**
 * The only module in the codebase allowed to touch localStorage. Everything
 * else — state stores included — goes through the functions here.
 */

const HISTORY_KEY = "blindfoldHistory";
const THEME_KEY = "blindfoldTheme";
const MAX_HISTORY = 100;

export function getGameHistory(): StoredGame[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as StoredGame[]) : [];
  } catch {
    return [];
  }
}

/** Appends a finished game, keeping only the most recent 100 — same shape/limit as the original app. */
export function saveGameToHistory(entry: StoredGame): void {
  try {
    const history = getGameHistory();
    history.push(entry);
    if (history.length > MAX_HISTORY) history.splice(0, history.length - MAX_HISTORY);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  } catch {
    // Private-mode / quota-exceeded localStorage — history just won't persist.
  }
}

export type ThemePreference = "light" | "dark";

export function getThemePreference(): ThemePreference | null {
  try {
    const raw = localStorage.getItem(THEME_KEY);
    return raw === "light" || raw === "dark" ? raw : null;
  } catch {
    return null;
  }
}

export function setThemePreference(theme: ThemePreference): void {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch {
    // ignore — theme just won't persist across reloads
  }
}
