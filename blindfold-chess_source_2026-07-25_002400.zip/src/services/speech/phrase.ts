import type { Move } from "chess.js";
import { movePhraseParts, type SpokenPart } from "../chess/san";
import type { GameEndReason } from "../chess/gameSummary";

/** Audio clip id — matches a filename in public/audio/<id>.wav. */
export type ClipId = SpokenPart;

/** A verbose chess.js move → the ordered clip ids to play for it. */
export function movePhraseClips(move: Move): ClipId[] {
  return movePhraseParts(move);
}

/**
 * Extra clips to play once a game ends. Checkmate is already carried by the
 * mating move's own "checkmate" clip, so it adds nothing further here.
 */
export function gameEndPhraseClips(reason: GameEndReason): ClipId[] {
  switch (reason) {
    case "stalemate":
      return ["stalemate"];
    case "threefold-repetition":
    case "insufficient-material":
    case "fifty-move-rule":
      return ["draw"];
    case "checkmate":
    case "resignation":
      return [];
  }
}
