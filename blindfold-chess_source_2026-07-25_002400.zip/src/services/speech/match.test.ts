import { describe, it, expect } from "vitest";
import { Chess } from "chess.js";
import { matchTranscript, matchBestAlternative } from "./match";
import { normalizeTranscript } from "./normalize";

describe("matchTranscript: moves", () => {
  it("matches a close variant to the right legal move", () => {
    const chess = new Chess();
    const result = matchTranscript(chess, normalizeTranscript("night to f three"));
    expect(result.type).toBe("move");
    if (result.type === "move") expect(result.move.san).toBe("Nf3");
  });

  it("rejects gibberish with no close move", () => {
    const chess = new Chess();
    const result = matchTranscript(chess, normalizeTranscript("what a lovely day for chess"));
    expect(result.type).toBe("none");
  });

  it("does not guess when two distinct legal moves are equally close", () => {
    // Knights on b4 and f4 can both capture the pawn on d5 — "knight
    // captures d5" is an equally valid candidate for either move.
    const chess = new Chess("8/8/8/3p4/1N3N2/8/8/K1k5 w - - 0 1");
    const result = matchTranscript(chess, normalizeTranscript("knight captures d5"));
    expect(result.type).toBe("none");
  });
});

describe("matchTranscript: commands", () => {
  it("matches a close command phrase", () => {
    const chess = new Chess();
    const result = matchTranscript(chess, normalizeTranscript("peek"));
    expect(result).toEqual({ type: "command", command: "peek", confidence: 1 });
  });

  it("never lets a move-shaped transcript resolve to a command", () => {
    const chess = new Chess();
    const result = matchTranscript(chess, normalizeTranscript("e4"));
    expect(result.type).not.toBe("command");
  });
});

describe("matchBestAlternative", () => {
  it("picks the best-scoring alternative across multiple recognition results", () => {
    const chess = new Chess();
    const result = matchBestAlternative(chess, ["gibberish nonsense", "knight to f3"]);
    expect(result.type).toBe("move");
    if (result.type === "move") expect(result.move.san).toBe("Nf3");
  });
});
