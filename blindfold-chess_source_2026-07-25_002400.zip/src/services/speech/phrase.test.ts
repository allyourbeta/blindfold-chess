import { describe, it, expect } from "vitest";
import { Chess } from "chess.js";
import { movePhraseClips, gameEndPhraseClips } from "./phrase";

describe("movePhraseClips", () => {
  it("wraps san.ts's phrase parts as clip ids", () => {
    const chess = new Chess();
    const move = chess.moves({ verbose: true }).find((m) => m.san === "e4")!;
    expect(movePhraseClips(move)).toEqual(["pawn", "to", "e", "4"]);
  });
});

describe("gameEndPhraseClips", () => {
  it("plays the stalemate clip for a stalemate", () => {
    expect(gameEndPhraseClips("stalemate")).toEqual(["stalemate"]);
  });

  it("plays the draw clip for the other draw reasons", () => {
    expect(gameEndPhraseClips("threefold-repetition")).toEqual(["draw"]);
    expect(gameEndPhraseClips("insufficient-material")).toEqual(["draw"]);
    expect(gameEndPhraseClips("fifty-move-rule")).toEqual(["draw"]);
  });

  it("plays nothing extra for checkmate or resignation", () => {
    expect(gameEndPhraseClips("checkmate")).toEqual([]);
    expect(gameEndPhraseClips("resignation")).toEqual([]);
  });
});
