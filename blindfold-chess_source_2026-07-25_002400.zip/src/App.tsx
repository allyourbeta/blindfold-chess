import { useEffect, useState } from "react";
import { MenuScreen } from "@/components/screens/MenuScreen";
import { SetupScreen } from "@/components/screens/SetupScreen";
import { PlayScreen } from "@/components/screens/PlayScreen";
import { useGameStore } from "@/state/gameStore";
import { useTheme } from "@/hooks/useTheme";

type Screen = "menu" | "setup" | "play";

export default function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const initEngine = useGameStore((s) => s.initEngine);
  useTheme();

  useEffect(() => {
    void initEngine();
  }, [initEngine]);

  // Spacebar peeks at the board whenever the move/FEN input isn't focused.
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.code !== "Space") return;
      if (document.activeElement instanceof HTMLInputElement) return;
      e.preventDefault();
      useGameStore.getState().doPeek();
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <div className="min-h-dvh bg-bg-base text-text-primary">
      {screen === "menu" && <MenuScreen onPlay={() => setScreen("play")} onSetup={() => setScreen("setup")} />}
      {screen === "setup" && <SetupScreen onBack={() => setScreen("menu")} onPlay={() => setScreen("play")} />}
      {screen === "play" && <PlayScreen onMenu={() => setScreen("menu")} />}
    </div>
  );
}
