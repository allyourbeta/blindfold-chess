#!/usr/bin/env bash
# Generates every spoken-move audio clip with the macOS `say` command and
# converts each to a web-friendly 16-bit PCM WAV. Clip ids match the
# SpokenPart/ClipId type in src/services/chess/san.ts — do not rename one
# without updating the other.
#
# Usage: bash scripts/generate-speech-clips.sh

set -euo pipefail

VOICE="Samantha"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_DIR="$SCRIPT_DIR/../public/audio"
mkdir -p "$OUT_DIR"

if ! command -v say >/dev/null 2>&1; then
  echo "error: the 'say' command is only available on macOS." >&2
  exit 1
fi
if ! command -v afconvert >/dev/null 2>&1; then
  echo "error: 'afconvert' not found (part of macOS Core Audio tools)." >&2
  exit 1
fi

# id:spoken text — id is also the output filename (id.wav).
CLIPS=(
  "king:king" "queen:queen" "rook:rook" "bishop:bishop" "knight:knight" "pawn:pawn"
  "a:Ay" "b:Bee" "c:See" "d:Dee" "e:Ee" "f:Eff" "g:Jee" "h:Aitch"
  "1:one" "2:two" "3:three" "4:four" "5:five" "6:six" "7:seven" "8:eight"
  "takes:takes" "to:to" "from:from" "check:check" "checkmate:checkmate"
  "castles-kingside:castles kingside" "castles-queenside:castles queenside"
  "promotes-to:promotes to" "en-passant:en passant"
  "stalemate:stalemate" "draw:draw"
)

echo "Generating ${#CLIPS[@]} clips with voice '$VOICE' into $OUT_DIR ..."

for entry in "${CLIPS[@]}"; do
  id="${entry%%:*}"
  text="${entry#*:}"
  aiff="$OUT_DIR/$id.aiff"
  wav="$OUT_DIR/$id.wav"

  say -v "$VOICE" -o "$aiff" "$text"
  afconvert -f WAVE -d LEI16@22050 "$aiff" "$wav"
  rm -f "$aiff"
  echo "  $id.wav <- \"$text\""
done

echo "Done. $(ls "$OUT_DIR"/*.wav | wc -l | tr -d ' ') clips in $OUT_DIR."
